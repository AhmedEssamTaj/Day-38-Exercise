package com.example.capstone2.Controller;

import com.example.capstone2.ApiResponse.ApiResponse;
import com.example.capstone2.Model.Comment;
import com.example.capstone2.Model.Meeting;
import com.example.capstone2.Service.MeetingService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/meeting")
@AllArgsConstructor
public class MeetingController {
    private final MeetingService meetingService;


    @GetMapping("/get-all")
    public ResponseEntity getAllMeetings() {
        return ResponseEntity.status(200).body(meetingService.getAllMeetings());
    }

    @PostMapping("/add")
    public ResponseEntity addMeeting(@RequestBody @Valid Meeting meeting) {

        meetingService.addMeeting(meeting);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully created meeting"));
    }
    @PutMapping("/update/{id}")
    public ResponseEntity updateMeeting(@PathVariable Integer id,@RequestBody @Valid Meeting meeting) {
        meetingService.updateMeeting(id, meeting);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully updated meeting"));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteMeeting(@PathVariable Integer id) {
       meetingService.deleteMeeting(id);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully deleted meeting"));
    }

    // endpoint to register user to attend meeting --- (10) ---
    @PostMapping("/attend/{userId}/{meetingId}")
    public ResponseEntity attendMeeting(@PathVariable Integer userId , @PathVariable Integer meetingId) {
        meetingService.attendMeeting(meetingId, userId);
        return ResponseEntity.status(200).body(new ApiResponse("user Successfully registered to attended meeting"));
    }

    // endpoint to close meeting --- (11) ---
    @PutMapping("/end/{userId}/{meetingId}/{outcome}")
    public ResponseEntity endMeeting(@PathVariable Integer userId ,@PathVariable Integer meetingId,@PathVariable String outcome) {
        meetingService.endMeeting(userId,meetingId,outcome);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully ended meeting"));
    }

}
