package com.example.capstone2.Model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MeetingAttendance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull(message = "user id cannot be empty")
    @Column(columnDefinition = "int not null")
    private Integer userId;

    @NotNull(message = "meeting id cannot be empty")
    @Column(columnDefinition = "int not null")
    private Integer meetingId;

    @NotNull(message = "registration must have date")
    @Column(columnDefinition = "timestamp not null")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private LocalDateTime registrationDate = LocalDateTime.now();

}
