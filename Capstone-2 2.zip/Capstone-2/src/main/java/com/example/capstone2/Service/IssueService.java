package com.example.capstone2.Service;

import com.example.capstone2.ApiResponse.ApiException;
import com.example.capstone2.Model.Issue;
import com.example.capstone2.Model.Post;
import com.example.capstone2.Model.UserAccount;
import com.example.capstone2.Repository.*;
import lombok.AllArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class IssueService {
    private final IssueRepository issueRepository;
    private final NeighborhoodRepository neighborhoodRepository;
    private final UserAccountRepository userAccountRepository;
    private final AdminAccountRepository adminAccountRepository;
    private final RewardService rewardService;
    private final UpVoteRepository upVoteRepository;

    // get all issues
    public List<Issue> getAllIssues() {
        return issueRepository.findAll();
    }

    // add
    public void addIssue(Issue issue) {
        if (!neighborhoodRepository.existsNeighborhoodById(issue.getNeighborhoodId())) {
            throw new ApiException("no neighborhood found");
        }
        if (!userAccountRepository.existsUserAccountById(issue.getUserId())) {
            throw new ApiException("no user found");
        }
        issueRepository.save(issue);
    }

    // update
    public void updateIssue(Integer id,Issue issue) {

        Issue oldIssue = issueRepository.findIssueById(id);
        if (oldIssue == null) {
            throw new ApiException("No issue with this id was found");
        }

        if (!neighborhoodRepository.existsNeighborhoodById(issue.getNeighborhoodId())) {
            throw new ApiException("no neighborhood found");
        }
        if (!userAccountRepository.existsUserAccountById(issue.getUserId())) {
            throw new ApiException("no user found");
        }
        oldIssue.setUserId(issue.getUserId());
        oldIssue.setNeighborhoodId(issue.getNeighborhoodId());
        oldIssue.setTitle(issue.getTitle());
        oldIssue.setDescription(issue.getDescription());
        oldIssue.setCategory(issue.getCategory());
        oldIssue.setStatus(issue.getStatus());
        oldIssue.setLatitude(issue.getLatitude());
        oldIssue.setLongitude(issue.getLongitude());
        oldIssue.setCreateMeeting(issue.getCreateMeeting());
        issueRepository.save(oldIssue);

    }
    // delete
    public void deleteIssue(Integer id) {
        Issue issue = issueRepository.findIssueById(id);
        if (issue == null) {
            throw new ApiException("No issue with this id was found");
        }
        issueRepository.delete(issue);
    }


    // method to close the issue (resolve) only by admin
    public void resolveIssue(Integer id, Integer issueId) {
        Issue issue = issueRepository.findIssueById(issueId);
        if (issue == null) {
            throw new ApiException("No issue with this id was found");
        }
        if(issue.getCreateMeeting()){
            throw new ApiException("Issue is scheduled for a meeting between neighborhood members");
        }
        if (issue.getStatus().equals("Resolved")) {
            throw new ApiException("issue is already resolved");
        }
        if (!adminAccountRepository.existsAdminAccountById(id)){
            throw new ApiException("no admin account found");
        }
        issue.setStatus("Resolved");
        issue.setClosedAt(LocalDateTime.now());
        issueRepository.save(issue);
//        rewardService.updateUserPoints(issue.getUserId()); // call method to handel user reward

    }

    // method to get all unresolved issues
    public List<Issue> getUresolvedIssues(Integer neighborhoodId) {
    List<Issue> unresolvedIssues = issueRepository.getAllIssueThatAreUnresolved(neighborhoodId);
    if (unresolvedIssues.isEmpty()) {
        throw new ApiException("no unresolved issues were found within this neighborhood");
    }
    return unresolvedIssues;
    }

    // method that runs each 5 min to check if there is issues that are overdue (change state)
    @Scheduled(fixedDelay = 300000) // every min has 60,000 millisecond
    public void updateOverdueIssues(){
        LocalDateTime tenDaysAgo = LocalDateTime.now().minusDays(10);
        List<Issue> overdueIssues = issueRepository.findByStatusAndCreatedAtBefore("Pending", tenDaysAgo);
        for (Issue issue : overdueIssues) {
            issue.setStatus("Overdue");
            issueRepository.save(issue);
        }
        System.out.println("an issue has been updated to Overdue! ");
    }

    // method to get the issues that are nearby to the user
    public List<Issue> getIssuesByCloser (Integer userId, int limit){

        UserAccount userAccount = userAccountRepository.findUserAccountById(userId);
        if (userAccount == null) {
            throw new ApiException("no user found");
        }
        List<Issue> closeIssues = issueRepository.findClosestIssues(userAccount.getLatitude()
        ,userAccount.getLongitude(),userAccount.getNeighborhoodId(),limit);

        if (closeIssues.isEmpty()) {
            throw new ApiException("no issues within this limit was found");
        }
        return closeIssues;

    }

    // method to get the overdue issues
    public List<Issue> getOverdueIssues(Integer neighborhoodId){
        List<Issue> overdueIssues = issueRepository.getOverdueIssues(neighborhoodId);
        if (overdueIssues.isEmpty()) {
            throw new ApiException("no overdue issues were found");
        }
        return overdueIssues;
    }

    // method to get the urgent issues for a neighborhood in the past 7 days
    public List<Issue> getUrgentIssues(Integer neighborhoodId){
        LocalDateTime weekAgo = LocalDateTime.now().minusDays(9);
        List<Issue> issues = issueRepository.findUrgentIssues(weekAgo, neighborhoodId);
        if (issues.isEmpty()) {
            throw new ApiException("no urgent issues was found");
        }

        issues.sort((issue1, issue2) -> {
            Integer upvotes1 = upVoteRepository.countUpVoteByIssueId(issue1.getId());
            Integer upvotes2 = upVoteRepository.countUpVoteByIssueId(issue2.getId());
            return upvotes2.compareTo(upvotes1); // Descending order
        });
        return issues;
    }
}
