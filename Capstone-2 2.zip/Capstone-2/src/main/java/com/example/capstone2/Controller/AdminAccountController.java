package com.example.capstone2.Controller;

import com.example.capstone2.ApiResponse.ApiResponse;
import com.example.capstone2.Model.AdminAccount;
import com.example.capstone2.Service.AdminAccountService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/admin")
@AllArgsConstructor
public class AdminAccountController {

    private final AdminAccountService adminAccountService;
    @GetMapping("/get-all")
    public ResponseEntity getAllAdminAccounts() {
        return ResponseEntity.status(200).body(adminAccountService.getAllAdminAccounts());
    }

    @PostMapping("/add")
    public ResponseEntity addAdminAccount(@RequestBody @Valid AdminAccount adminAccount) {

        adminAccountService.addAdminAccount(adminAccount);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully added admin account"));
    }
    @PutMapping("/update/{id}")
    public ResponseEntity updateAdminAccount(@PathVariable Integer id,@RequestBody @Valid AdminAccount adminAccount) {
        adminAccountService.updateAdminAccount(id, adminAccount);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully updated admin account"));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteAdminAccount(@PathVariable Integer id) {
        adminAccountService.deleteAdminAccount(id);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully deleted admin account"));
    }






}
