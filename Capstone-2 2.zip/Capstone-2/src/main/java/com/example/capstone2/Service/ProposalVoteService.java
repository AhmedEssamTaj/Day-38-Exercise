package com.example.capstone2.Service;

import com.example.capstone2.ApiResponse.ApiException;
import com.example.capstone2.Model.Proposal;
import com.example.capstone2.Model.ProposalVote;
import com.example.capstone2.Repository.ProposalRepository;
import com.example.capstone2.Repository.ProposalVoteRepository;
import com.example.capstone2.Repository.UserAccountRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
@AllArgsConstructor
public class ProposalVoteService {
    private final ProposalVoteRepository proposalVoteRepository;
    private final ProposalRepository proposalRepository;
    private final UserAccountRepository userAccountRepository;

    // get all proposal votes
    public List<ProposalVote> findAll() {
        return proposalVoteRepository.findAll();
    }

    // vote
    public void  vote(ProposalVote proposalVote) {

        if (!userAccountRepository.existsUserAccountById(proposalVote.getUserId())){
            throw new ApiException("No user with this id was found");
        }

        if (!proposalRepository.existsProposalById(proposalVote.getProposalId())) {
            throw new ApiException("No proposal with this id was found");
        }

        if (proposalVoteRepository.existsProposalVoteByUserIdAndProposalId(proposalVote.getUserId(), proposalVote.getProposalId())) {
            throw new ApiException("user already voted on this proposal");
        }

        Proposal proposal = proposalRepository.findProposalById(proposalVote.getProposalId());
        if(proposal.getUserId().equals(proposalVote.getUserId())){
            throw new ApiException("user cannot vote on his own proposal");
        }
        if(proposal.getIsClosed()){
            throw new ApiException("voting for this proposal is closed");
        }
        if(!Objects.equals(userAccountRepository.findUserAccountById(proposalVote.getUserId()).getNeighborhoodId(), proposalRepository.findProposalById(proposalVote.getProposalId()).getNeighborhoodId())){
            throw new ApiException("user can only vote in his own neighborhood");
        }

        proposalVoteRepository.save(proposalVote);
    }

    // update vote
    public void updateVote(Integer id,ProposalVote proposalVote) {
       ProposalVote oldVote = proposalVoteRepository.findProposalVoteById(id);
        if(oldVote == null){
            throw new ApiException("No proposal vote with this id was found");
        }
        oldVote.setInFavor(proposalVote.isInFavor());
        proposalVoteRepository.save(oldVote);

    }

    // delete
    public void deleteVote(Integer id) {
        ProposalVote proposalVote = proposalVoteRepository.findProposalVoteById(id);
        if (proposalVote == null) {
            throw new ApiException("No proposal vote with this id was found");
        }
        proposalVoteRepository.delete(proposalVote);
    }
}
