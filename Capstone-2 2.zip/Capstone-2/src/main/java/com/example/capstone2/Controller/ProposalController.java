package com.example.capstone2.Controller;

import com.example.capstone2.ApiResponse.ApiResponse;
import com.example.capstone2.Model.Post;
import com.example.capstone2.Model.Proposal;
import com.example.capstone2.Service.ProposalService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/proposal")
@AllArgsConstructor
public class ProposalController {
    private final ProposalService proposalService;

    @GetMapping("/get-all")
    public ResponseEntity getAllProposals() {
        return ResponseEntity.status(200).body(proposalService.getAllProposals());
    }

    @PostMapping("/add")
    public ResponseEntity addProposal(@RequestBody @Valid Proposal proposal) {
        proposalService.addProposal(proposal);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully added proposal"));
    }
    @PutMapping("/update/{id}")
    public ResponseEntity updateProposal(@PathVariable Integer id,@RequestBody @Valid Proposal proposal) {
        proposalService.updateProposal(id, proposal);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully updated proposal"));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteProposal(@PathVariable Integer id) {
        proposalService.deleteProposal(id);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully deleted proposal"));
    }

    // endpoint for admin to approve / reject a proposal --- (3) ---
    @PutMapping("/proposal-decision/{adminId}/{proposalId}")
    public ResponseEntity proposalDecision (@PathVariable Integer adminId, @PathVariable Integer proposalId ) {
        return ResponseEntity.status(200).body(new ApiResponse(proposalService.proposalDecision(adminId, proposalId)));

    }

    // endpoint to get user proposals
    @GetMapping("/get-user/{userId}")
    public ResponseEntity getProposalByUserId(@PathVariable Integer userId) {
        return ResponseEntity.status(200).body(proposalService.getProposalByUserId(userId));
    }
}
