package com.example.capstone2.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Check;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Reward {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull(message = "user id cannot be empty")
    @Column(columnDefinition = "int not null")
    private Integer userId;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Column(columnDefinition = "int default 0")
    private Integer points=0;


    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Pattern(regexp = "^(Beginner|Contributor|Helper|Problem Solver|Neighborhood Hero)$")
    @Column(columnDefinition = "varchar(17) default 'Beginner'")
    @Check(constraints = "type IN ('Beginner', 'Contributor','Problem Solver','Neighborhood Hero')")
    private String badge="Beginner";

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Column(columnDefinition = "varchar(25) unique")
    private String userName;

}
