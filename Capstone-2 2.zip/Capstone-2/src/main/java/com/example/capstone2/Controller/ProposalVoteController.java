package com.example.capstone2.Controller;

import com.example.capstone2.ApiResponse.ApiResponse;
import com.example.capstone2.Model.Proposal;
import com.example.capstone2.Model.ProposalVote;
import com.example.capstone2.Service.ProposalVoteService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/proposal/vote")
@AllArgsConstructor
public class ProposalVoteController {
    private final ProposalVoteService proposalVoteService;

    @GetMapping("/get-all")
    public ResponseEntity getAllProposalsVotes() {
        return ResponseEntity.status(200).body(proposalVoteService.findAll());
    }

    // end point to vote for a proposal --- (4) ---
    @PostMapping("/add")
    public ResponseEntity addProposalVote(@RequestBody @Valid ProposalVote proposalVote) {

        proposalVoteService.vote(proposalVote);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully added vote"));
    }
    @PutMapping("/update/{id}")
    public ResponseEntity updateProposalVote(@PathVariable Integer id,@RequestBody @Valid ProposalVote proposalVote) {

        proposalVoteService.updateVote(id, proposalVote);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully updated vote"));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteProposalVote(@PathVariable Integer id) {
        proposalVoteService.deleteVote(id);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully deleted vote"));
    }

}
