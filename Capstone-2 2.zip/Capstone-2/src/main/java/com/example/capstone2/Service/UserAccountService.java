package com.example.capstone2.Service;

import com.example.capstone2.ApiResponse.ApiException;
import com.example.capstone2.Model.Issue;
import com.example.capstone2.Model.Meeting;
import com.example.capstone2.Model.Reward;
import com.example.capstone2.Model.UserAccount;
import com.example.capstone2.Repository.*;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class UserAccountService {
    private final UserAccountRepository userAccountRepository;
    private final NeighborhoodRepository neighborhoodRepository;
    private final RewardRepository rewardRepository;

    public List<UserAccount> getAllUserAccounts() {
        return userAccountRepository.findAll();
    }

    // get all users
    public List<UserAccount> getAllUsers(){
        return userAccountRepository.findAll();
    }

    // add user
    public void addUserAccount(UserAccount userAccount) {

        if (! neighborhoodRepository.existsNeighborhoodById(userAccount.getNeighborhoodId())) {
            throw new ApiException("No neighborhood with this id found");
        }

        userAccountRepository.save(userAccount);
        Reward reward = new Reward();
        reward.setUserId(userAccount.getId());
        reward.setUserName(userAccount.getName());
        rewardRepository.save(reward);

    }

    // update
    public void updateUserAccount(Integer id,UserAccount userAccount) {
        UserAccount oldUserAccount = userAccountRepository.findUserAccountById(id);
        if (oldUserAccount == null) {
            throw new ApiException("No such user account was found");
        }
        if (!neighborhoodRepository.existsNeighborhoodById(userAccount.getNeighborhoodId())) {
            throw new ApiException("No neighborhood with this id found");
        }
        oldUserAccount.setName(userAccount.getName());
        oldUserAccount.setPassword(userAccount.getPassword());
        oldUserAccount.setEmail(userAccount.getEmail());
        oldUserAccount.setNeighborhoodId(userAccount.getNeighborhoodId());
        oldUserAccount.setLatitude(userAccount.getLatitude());
        oldUserAccount.setLongitude(userAccount.getLongitude());
        userAccountRepository.save(oldUserAccount);
    }

    // delete
    public void deleteUserAccount(Integer id) {
        UserAccount userAccount = userAccountRepository.findUserAccountById(id);
        if (userAccount == null) {
            throw new ApiException("No such user account was found");
        }
        userAccountRepository.delete(userAccount);
    }


}
