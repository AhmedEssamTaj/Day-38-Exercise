package com.example.capstone2.Controller;

import com.example.capstone2.ApiResponse.ApiResponse;
import com.example.capstone2.Model.AdminAccount;
import com.example.capstone2.Model.Meeting;
import com.example.capstone2.Model.UserAccount;
import com.example.capstone2.Service.MeetingService;
import com.example.capstone2.Service.UserAccountService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/user")
@AllArgsConstructor
public class UserAccountController {
    private final UserAccountService userAccountService;

    @GetMapping("/get-all")
    public ResponseEntity getAllUserAccounts() {
        return ResponseEntity.status(200).body(userAccountService.getAllUserAccounts());
    }

    @PostMapping("/add")
    public ResponseEntity addUserAccount(@RequestBody @Valid UserAccount userAccount) {

        userAccountService.addUserAccount(userAccount);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully added user account"));
    }
    @PutMapping("/update/{id}")
    public ResponseEntity updateUserAccount(@PathVariable Integer id,@RequestBody @Valid UserAccount userAccount) {

        userAccountService.updateUserAccount(id, userAccount);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully updated user account"));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteAdminAccount(@PathVariable Integer id) {
        userAccountService.deleteUserAccount(id);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully deleted user account"));
    }


}
