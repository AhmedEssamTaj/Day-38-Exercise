package com.example.capstone2.Model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Meeting {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull(message = "user id cannot be empty")
    @Column(columnDefinition = "int not null")
    private Integer userId;

    @NotNull(message = "vote must be connected to a issue")
    @Column(columnDefinition = "int not null")
    private Integer issueId;

    @NotNull(message = "meeting must have time")
    @Column(columnDefinition = "timestamp not null")
    @FutureOrPresent
    private LocalDateTime meetingTime;

    @NotEmpty(message = "Title cannot be empty")
    @Column(columnDefinition = "varchar(35) not null")
    private String title;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Pattern(regexp = "^(Not Solved|Solved|Cancelled)$")
    @Column(columnDefinition = "varchar(10)")
    private String outcome ;

    @NotEmpty(message = "meeting location must be specified")
    @Column(columnDefinition = "varchar(50) not null")
    private String location;



}
