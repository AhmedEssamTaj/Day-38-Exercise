package com.example.capstone2.Repository;

import com.example.capstone2.Model.MeetingAttendance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

@Repository
public interface MeetingAttendanceRepository extends JpaRepository<MeetingAttendance,Integer> {
    MeetingAttendance findMeetingAttendanceById(int id);

    Boolean existsMeetingAttendanceByUserIdAndMeetingId(Integer userId, Integer meetingId);

    @Query("select count (a) from MeetingAttendance a where a.userId = ?1 and a.meetingId in " +
            "(select m.id from Meeting m where m.meetingTime = ?2)")
    Integer countUserRegisteredAtSameTime(Integer userId, LocalDateTime meetingTime);

    Integer countByMeetingId(Integer meetingId);

    Integer countByUserId(Integer userId);
}
