package com.example.capstone2.Controller;

import com.example.capstone2.ApiResponse.ApiResponse;
import com.example.capstone2.Model.Proposal;
import com.example.capstone2.Model.Reward;
import com.example.capstone2.Service.RewardService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/reward")
@AllArgsConstructor
public class RewardController {
    private final RewardService rewardService;

    @GetMapping("/get-all")
    public ResponseEntity getAllRewards() {
        return ResponseEntity.status(200).body(rewardService.getAllRewards());
    }


    @PutMapping("/update/{adminId}/{rewardId}")
    public ResponseEntity updateReward(@PathVariable Integer adminId, @PathVariable Integer rewardId, @RequestBody @Valid Reward reward) {

        rewardService.updateReward(adminId, rewardId, reward);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully updated reward"));
    }

    @DeleteMapping("/delete/{adminId}/{rewardId}")
    public ResponseEntity deleteProposal(@PathVariable Integer adminId,@PathVariable Integer rewardId) {
        rewardService.deleteReward(adminId, rewardId);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully deleted reward"));
    }

    // endpoint to calculate user reward --- (8) ---
    @GetMapping("/get-user/{userId}")
    public ResponseEntity getUserReward(@PathVariable Integer userId) {
        return ResponseEntity.status(200).body(rewardService.calculateUserReward(userId));
    }

    // endpoint to get leaderboards --- (12)---
    @GetMapping("/get-leaderboards/{neighborhoodId}")
    public ResponseEntity getLeaderBoards (@PathVariable Integer neighborhoodId){
        return ResponseEntity.status(200).body(rewardService.getLeaderboard(neighborhoodId));
    }
}
