package com.example.capstone2.Model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Check;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Post {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull(message = "user id cannot be empty")
    @Column(columnDefinition = "int not null")
    private Integer userId;

    @NotNull(message = "neighborhood id cannot be empty")
    @Column(columnDefinition = "int not null")
    private Integer neighborhoodId;

    @NotEmpty(message = "you must choose a type")
    @Pattern(regexp = "^(Announcement|Offer|Invitation|Request|Other)$")
    @Column(columnDefinition = "varchar(12) not null")
    @Check(constraints = "type IN ('Announcement', 'Offer','Invitation','Request','Other')")
    private String type;

    @NotEmpty(message = "title cannot be empty")
    @Size(min = 6, max = 40,message = "title must be more then 6 and less than or equal to 40 char")
    @Column(columnDefinition = "varchar(40) not null")
    @Check(constraints = "CHAR_LENGTH(title) >= 6")
    private String title;

    @NotEmpty(message = "description cannot be empty")
    @Size(min = 20, max = 350,message = "description must be more then 20 and less than or equal to 350 char")
    @Column(columnDefinition = "varchar(350) not null")
    @Check(constraints = "CHAR_LENGTH(description) >= 20")
    private String description;

    @NotNull(message = "creation date cannot be null")
    @Column(columnDefinition = "timestamp default current_timestamp")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @PastOrPresent
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(columnDefinition = "timestamp")
//    @FutureOrPresent
    private LocalDateTime expiresAt ;

}
