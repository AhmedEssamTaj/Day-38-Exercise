package com.example.capstone2.Repository;

import com.example.capstone2.Model.Proposal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ProposalRepository extends JpaRepository<Proposal, Integer> {

    Proposal findProposalById(Integer id);

    boolean existsProposalById(Integer id);

    List<Proposal> findAllByClosingDateBeforeAndIsClosedFalse(LocalDateTime now);

    List<Proposal> findProposalByUserId(Integer userId);
}
