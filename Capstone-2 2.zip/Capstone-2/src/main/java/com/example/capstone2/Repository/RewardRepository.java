package com.example.capstone2.Repository;

import com.example.capstone2.Model.Reward;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RewardRepository extends JpaRepository<Reward, Integer> {

    Reward findRewardById(Integer id);

    boolean existsRewardById(Integer id);

    Reward findRewardByUserId(Integer userId);

    @Query("select r from Reward r order by r.points desc ")
    List<Reward> findLeaderBoards();
}
