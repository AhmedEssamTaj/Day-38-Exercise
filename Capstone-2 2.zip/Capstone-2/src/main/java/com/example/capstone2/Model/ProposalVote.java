package com.example.capstone2.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProposalVote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull(message = "proposal id must be filled")
    @Column(columnDefinition = "int not null")
    private Integer proposalId;

    @NotNull(message = "user id must be filled")
    @Column(columnDefinition = "int not null")
    private Integer userId;
    @NotNull(message = "vote cannot be null")
    @Column(columnDefinition = "boolean not null")
    private boolean inFavor;

}
