package com.example.capstone2.Service;

import com.example.capstone2.ApiResponse.ApiException;
import com.example.capstone2.Model.Comment;
import com.example.capstone2.Repository.CommentRepository;
import com.example.capstone2.Repository.IssueRepository;
import com.example.capstone2.Repository.PostRepository;
import com.example.capstone2.Repository.UserAccountRepository;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class CommentService {
    private final CommentRepository commentRepository;
    private final UserAccountRepository userAccountRepository;
    private final PostRepository postRepository;

    // get all comments
    public List<Comment> getAllComments() {
        return commentRepository.findAll();
    }

    // add
    public void addComment(Comment comment) {
        if (!userAccountRepository.existsUserAccountById(comment.getUserId())){
            throw new ApiException("User account does not exist");
        }
        if (!postRepository.existsPostById(comment.getPostId())){
            throw new ApiException("post does not exist");
        }
        commentRepository.save(comment);
    }

    // update
    public void updateComment(Integer id,Comment comment) {
        Comment oldComment = commentRepository.findCommentById(id);
        if (oldComment == null) {
            throw new ApiException("Comment does not exist");
        }
        if (!userAccountRepository.existsUserAccountById(comment.getUserId())){
            throw new ApiException("User account does not exist");
        }
        if (!postRepository.existsPostById(comment.getPostId())){
            throw new ApiException("post does not exist");
        }
        oldComment.setComment(comment.getComment());
        oldComment.setPostId(comment.getPostId());
        oldComment.setUserId(comment.getUserId());
        commentRepository.save(oldComment);
    }

    // delete
    public void deleteComment(Integer id) {
        Comment comment = commentRepository.findCommentById(id);
        if (comment == null) {
            throw new ApiException("Comment does not exist");
        }
        commentRepository.delete(comment);
    }

    // method to get all the comment on a post
    public List<Comment> getCommentsByPostId(Integer postId) {
        if (!postRepository.existsPostById(postId)) {
            throw new ApiException("Post does not exist");
        }
        List<Comment> comments = commentRepository.findCommentByPostId(postId);
        if (comments.isEmpty()) {
            throw new ApiException("post has no comments");
        }
        return comments;
    }



}
