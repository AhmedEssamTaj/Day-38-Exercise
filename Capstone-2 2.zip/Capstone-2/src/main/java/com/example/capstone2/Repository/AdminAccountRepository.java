package com.example.capstone2.Repository;

import com.example.capstone2.Model.AdminAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminAccountRepository extends JpaRepository<AdminAccount, Integer> {

    AdminAccount findAdminAccountById(Integer id);

    Boolean existsAdminAccountById(Integer id);

}
