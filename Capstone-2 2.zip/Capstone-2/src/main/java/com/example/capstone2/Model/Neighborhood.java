package com.example.capstone2.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Neighborhood {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotEmpty(message = "city cannot be empty")
    @Size(min = 3, max = 30, message = "city must be at least of length 3 and at most 30")
    @Column(columnDefinition = "varchar(30) not null")
    private String city;

    @NotEmpty(message = "name cannot be empty")
    @Size(min = 3 , max = 30, message = "neighborhood name must be at least of length 3 and at most 30")
    @Column(columnDefinition = "varchar(30) not null")
    private String name;

    @NotNull(message = "latitude cannot be null")
    @Column(columnDefinition = "double not null")
    private Double latitude;

    @NotNull(message = "longitude cannot be null")
    @Column(columnDefinition = "double not null")
    private Double longitude;
}
