package com.example.capstone2.Controller;

import com.example.capstone2.Service.MeetingAttendanceService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/v1/meeting/attendance")
@AllArgsConstructor
public class MeetingAttendanceController {
    private final MeetingAttendanceService meetingAttendanceService;

    @GetMapping("/get-all")
    public ResponseEntity getAllMeetingAttendance(){
        return ResponseEntity.status(200).body(meetingAttendanceService.getAllMeetingAttendance());
    }
}
