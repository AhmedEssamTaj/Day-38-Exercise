package com.example.capstone2.Controller;

import com.example.capstone2.ApiResponse.ApiResponse;
import com.example.capstone2.Model.Comment;
import com.example.capstone2.Model.Issue;
import com.example.capstone2.Service.IssueService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/issue")
@AllArgsConstructor
public class IssueController {
    private final IssueService issueService;

    @GetMapping("/get-all")
    public ResponseEntity getAllIssues() {
        return ResponseEntity.status(200).body(issueService.getAllIssues());
    }

    @PostMapping("/add")
    public ResponseEntity addIssue(@RequestBody @Valid Issue issue) {
        issueService.addIssue(issue);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully added issue"));
    }
    @PutMapping("/update/{id}")
    public ResponseEntity updateIssue(@PathVariable Integer id,@RequestBody @Valid Issue issue) {
        issueService.updateIssue(id, issue);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully updated issue"));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteIssue(@PathVariable Integer id) {
        issueService.deleteIssue(id);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully deleted issue"));
    }

    // endpoint to close an issue (resolved) --- (1) ---
    @PutMapping("/resolve/{adminId}/{issueId}")
    public ResponseEntity resolveIssue (@PathVariable Integer adminId, @PathVariable Integer issueId) {
        issueService.resolveIssue(adminId, issueId);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully resolved issue"));
    }

    // endpoint to get all unresolved issues WITHIN a neighborhood
    @GetMapping("/get-unresolved/{neighborhoodId}")
    public ResponseEntity getUnresolvedIssues(@PathVariable Integer neighborhoodId) {
        return ResponseEntity.status(200).body(issueService.getUresolvedIssues(neighborhoodId));
    }

    // endpoint to get all issues that are nearby to the user --- (2) ---
    @GetMapping("/get-nearby/{userId}/{limit}")
    public ResponseEntity getNearbyIssue (@PathVariable Integer userId, @PathVariable int limit) {

        return ResponseEntity.status(200).body(issueService.getIssuesByCloser(userId, limit));

    }


    // endpoint to get overdue issues within a neighborhood --- (5) ---
    @GetMapping("/get-overdue/{neighborhoodId}")
    public ResponseEntity getOverdueIssues (@PathVariable Integer neighborhoodId) {
        return ResponseEntity.status(200).body(issueService.getOverdueIssues(neighborhoodId));
    }

    // endpoint to get urgent issues the list of most up voted issues that in the past 7 days --- (6) ---
    @GetMapping("/get-urgent/{neighborhoodId}")
    public ResponseEntity getUrgentIssues (@PathVariable Integer neighborhoodId) {
        return ResponseEntity.status(200).body(issueService.getUrgentIssues(neighborhoodId));
    }
}
